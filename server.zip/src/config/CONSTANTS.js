export const webPush = { publicKey:
  'BMafx5AouBAMLpe2knXFHriVYN4yQWcO1oc9OLOWacfUXk7uyKuZMF_VLPUZY4T3j3-WQuyO9GjhdIgIGsgD9fU',
 privateKey: 'ilTIN07MXjCNIjYWp6m0KHUkN5pEOVBKy65pFc-86oQ' }